"use client";

import { useEffect, useState } from "react";

import { useLocalUserSettings } from "~/shared/hooks/use-local-user-settings";
import { indexedDB } from "~/shared/lib/api/dexie";
import type { History } from "~/shared/types-schema/types";

import GridContainer from "~/widgets/grid-container";
import {
  PublicContentContainer,
  PublicHeaderTitle,
  PublicMainContainer,
  PublicMarker,
} from "~/widgets/public-layout";
import YouTubeCard from "~/widgets/youtube/youtube-card";

export default function ContinueWatching() {
  const [history, setHistory] = useState<History[]>([]);

  const { localUserSettings } = useLocalUserSettings(null);

  useEffect(() => {
    const getWatchHistory = async () => {
      const indexedHistory =
        (await indexedDB["history"]
          .toCollection()
          .reverse()
          .sortBy("updatedAt")) ?? [];

      const filteredIndexedHistory = indexedHistory.filter(
        (item) => item.completed < localUserSettings.watchedPercentage
      );
      setHistory(filteredIndexedHistory);
    };

    getWatchHistory();
  }, []);

  if (history.length) {
    return (
      <PublicMainContainer>
        <PublicHeaderTitle>
          <div className="flex h-7 gap-2 text-lg tracking-wide md:text-2xl">
            <PublicMarker />
            <h1>Continue Watching</h1>
          </div>
        </PublicHeaderTitle>
        <PublicContentContainer>
          <GridContainer>
            {history.slice(0, 4).map((item) => (
              // TODO: Track video progression
              <YouTubeCard
                key={item.videoId}
                options={{
                  enableJsApi: true,
                  showVideoStats: true,
                  showDuration: true,
                }}
                video={item}
              />
            ))}
          </GridContainer>
        </PublicContentContainer>
      </PublicMainContainer>
    );
  }
  return null;
}