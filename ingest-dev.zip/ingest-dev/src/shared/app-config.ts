import packageInfo from "../../package.json" with { type: "json" };
import isDevelopment from "./utils/is-development";
import { time } from "./utils/time";

class AppConfig {
  private _catalogUpdateEnabled = process.env.ENABLE_CATALOG_UPDATE;
  private _catalogUpdatePeriod = time.hours(4);
  private _catalogVideoLimit = 10;
  private _channelLogoUpdatePeriod = time.days(1);
  private _domain = "707x.in";
  private _githubRepo = "https://github.com/realChakrawarti/ingest";
  private _limitArchives = 10;
  private _limitCatalogs = 5;
  private _marketName = "Ingest";
  private _name = packageInfo.name;
  private _organization = "707x Labs";
  private _subDomain = "ingest";
  private _version = packageInfo.version;
  private _watchedPercentage = 94;
  private _tracesSampleRate = 0.5;
  private _metadataUpdateCooldown = time.hours(4);
  private _exploreFeatured = true;

  get catalogUpdateEnabled(): boolean {
    return (
      (this._catalogUpdateEnabled && Boolean(process.env.YOUTUBE_API_KEY)) ||
      !isDevelopment()
    );
  }

  get exploreFeatured(): boolean {
    return this._exploreFeatured;
  }

  get metadataUpdateCooldown(): number {
    return this._metadataUpdateCooldown;
  }

  get channelLogoUpdatePeriod(): number {
    return this._channelLogoUpdatePeriod;
  }

  get catalogVideoLimit(): number {
    return this._catalogVideoLimit;
  }

  get catalogUpdatePeriod(): number {
    return this._catalogUpdatePeriod;
  }

  get watchedPercentage(): number {
    return this._watchedPercentage;
  }

  get url(): string {
    return isDevelopment()
      ? "http://localhost:3000"
      : `https://${this._subDomain}.${this._domain}`;
  }

  get domain(): string {
    return this._domain;
  }

  get marketName(): string {
    return this._marketName;
  }

  get name(): string {
    return this._name;
  }

  get subDomain(): string {
    return this._subDomain;
  }

  get version(): string {
    return this._version;
  }

  get organization(): string {
    return this._organization;
  }

  get githubRepo(): string {
    return this._githubRepo;
  }

  get limitCatalogs(): number {
    return this._limitCatalogs;
  }

  get limitArchives(): number {
    return this._limitArchives;
  }

  get tracesSampleRate(): number | undefined {
    if (!isDevelopment()) {
      return this._tracesSampleRate;
    }
    return undefined;
  }
}

const appConfig = new AppConfig();

export default appConfig;