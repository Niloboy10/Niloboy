"use client";

import { FlameIcon, MessageSquareText, TrendingUp } from "lucide-react";

import { useLiveQuery } from "dexie-react-hooks";

import type { ZVideoContentInfo } from "~/entities/catalogs/models";

import { useLocalUserSettings } from "~/shared/hooks/use-local-user-settings";
import { indexedDB } from "~/shared/lib/api/dexie";
import { time } from "~/shared/utils/time";

import OverlayTip from "../overlay-tip";
import useActivePlayerRef from "./use-active-player";

interface CategoryThresholds {
  trending: { minViews: number; minLikes: number; minComments: number };
  controversial: { minComments: number; commentToLikeRatio: number };
  hot: { minViews: number; minEngagementRate: number };
}

const CATEGORY_THRESHOLDS: CategoryThresholds = {
  controversial: { commentToLikeRatio: 0.1, minComments: 50 },
  hot: { minEngagementRate: 0.03, minViews: 50_000 },
  trending: { minComments: 100, minLikes: 5_000, minViews: 100_000 },
};

/**
 * Categorizes a video based on its views, likes, and comments.
 * Returns "Trending", "Controversial", "Hot", or "Inconclusive".
 *
 * @param {number} views - The number of views the video has.
 * @param {number} likes - The number of likes the video has.
 * @param {number} comments - The number of comments the video has.
 * @returns {string} The category of the video.
 */
function categorizeVideoSimplified(
  views: number,
  likes: number,
  comments: number
): "Trending" | "Controversial" | "Hot" | "Inconclusive" {
  let engagementRate = 0;
  if (views === 0) {
    engagementRate = 0;
  } else {
    engagementRate = (likes + comments) / views;
  }

  let commentToLikeRatio = 0;
  if (likes === 0) {
    if (comments > 0) {
      commentToLikeRatio = Math.min(comments * 10, 100);
    } else {
      commentToLikeRatio = 0;
    }
  } else {
    commentToLikeRatio = comments / likes;
  }

  // Check for TRENDING
  if (
    views >= CATEGORY_THRESHOLDS.trending.minViews &&
    likes >= CATEGORY_THRESHOLDS.trending.minLikes &&
    comments >= CATEGORY_THRESHOLDS.trending.minComments
  ) {
    return "Trending";
  }

  // Check for CONTROVERSIAL (if not Trending)
  if (
    comments >= CATEGORY_THRESHOLDS.controversial.minComments &&
    commentToLikeRatio >= CATEGORY_THRESHOLDS.controversial.commentToLikeRatio
  ) {
    return "Controversial";
  }

  // Check for HOT (if not Trending or Controversial)
  if (
    views >= CATEGORY_THRESHOLDS.hot.minViews &&
    engagementRate >= CATEGORY_THRESHOLDS.hot.minEngagementRate
  ) {
    return "Hot";
  }

  return "Inconclusive";
}
const Icons = {
  Controversial: MessageSquareText,
  Hot: FlameIcon,
  Trending: TrendingUp,
} as const;

function olderThanAWeek(date: string) {
  const currentTime = Date.now();
  const dateTime = new Date(date).getTime();

  return currentTime - dateTime > time.weeks(1);
}

export function VideoCategory({
  videoViews,
  videoLikes,
  videoComments,
  videoId,
  publishedAt,
}: Omit<
  ZVideoContentInfo,
  "videoDuration" | "videoAvailability" | "defaultVideoLanguage"
> & {
  videoId: string;
  publishedAt: string;
}) {
  const activePlayerRef = useActivePlayerRef();
  const { localUserSettings } = useLocalUserSettings(null);

  const videoProgress = useLiveQuery(() => indexedDB["history"].get(videoId));

  if (olderThanAWeek(publishedAt)) return null;

  const category = categorizeVideoSimplified(
    videoViews,
    videoLikes,
    videoComments
  );

  if (activePlayerRef?.getVideoData()?.video_id === videoId) {
    return null;
  }

  if (
    category === "Inconclusive" ||
    (videoProgress &&
      videoProgress.completed > localUserSettings.watchedPercentage)
  ) {
    return null;
  }
  const IconComponent = Icons[category];

  return (
    <div className="absolute top-2 left-0.5 cursor-default md:left-0">
      <OverlayTip
        className="flex place-items-center gap-1 rounded-r-md px-1.25 py-2"
        id="video-category"
        aria-label="Video category"
      >
        <div className="flex items-center gap-1 text-xs">
          <IconComponent className="size-4" />
          <p className="hidden items-center gap-1 group-hover/player:flex">
            <span>{category}</span>
          </p>
        </div>
      </OverlayTip>
    </div>
  );
}