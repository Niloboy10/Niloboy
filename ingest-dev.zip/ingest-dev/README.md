# <img src="https://github.com/realChakrawarti/ingest/blob/main/public/icon.png" alt="Dev.to Rater" height="30"/> Ingest: Organize Your YouTube Experience

## Project Stats

![Project Analytics](https://repobeats.axiom.co/api/embed/aa9709544fd4bfdfd08f689d869b2be6d75bdfd9.svg "Repobeats analytics image")

![CodeRabbit Pull Request Reviews](https://img.shields.io/coderabbit/prs/github/realChakrawarti/ingest?utm_source=oss&utm_medium=github&utm_campaign=realChakrawarti%2Fingest&labelColor=171717&color=FF570A&link=https%3A%2F%2Fcoderabbit.ai&label=CodeRabbit+Reviews)

<div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap;">
<img src="https://img.shields.io/github/stars/realChakrawarti/ingest" alt="GitHub Repo stars" />
<img src="https://img.shields.io/github/license/realChakrawarti/ingest" alt="GitHub License" />
<img src="https://img.shields.io/github/issues/realChakrawarti/ingest" alt="GitHub Issues" />
<img src="https://img.shields.io/github/commit-activity/m/realChakrawarti/ingest" alt="Commit Activity" />
<img alt="GitHub top language" src="https://img.shields.io/github/languages/top/realChakrawarti/ingest">
</div>

## Introduction

![ingest-homepage](./screen-capture.png)

Do you ever find yourself lost in a YouTube wormhole, spending hours watching unrelated videos? Ingest is here to help!

This web application empowers you to take control of your YouTube viewing by creating personalized catalogs of your favorite channels. Organize and curate content from channels you find valuable, making it easy to find the videos you want to watch later.

### Key Features:

- **Channel Catalog Creation:** Effortlessly build a list of YouTube channels you enjoy. Add them to your catalog for quick access.
- **Automatic Updates (Every 4 Hours):** Stay informed! Ingest automatically refreshes your catalog every 4 hours upon revisiting the page.
- **Seamless Sharing:** Share your curated catalogs with friends, family, or online communities who share your interests.

### Benefits:

- **Save Time:** No more aimlessly scrolling through YouTube's recommendations. Find the videos you're truly interested in quickly.
- **Stay Updated:** Never miss a new video from your favorite channels again.
- **Organize and Share:** Keep your YouTube viewing organized and share your curated selections with others.

<hr />

# Contributing

Read the [contributing](./CONTRIBUTING.md) guide.

<hr/>

### Contributors

<a href="https://github.com/realChakrawarti/ingest/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=realChakrawarti/ingest" />
</a>
